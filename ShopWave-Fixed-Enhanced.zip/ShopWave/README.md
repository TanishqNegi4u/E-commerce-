# ShopWave E-Commerce Platform - Fixed & Enhanced Edition

A full-stack e-commerce app built with **Spring Boot (Java 17)** + **MySQL / PostgreSQL** backend and a clean **HTML/CSS/JS** frontend with modern **dark theme**.

## ✨ What's New in This Version

### 🔧 Fixed Issues
- ✅ **Dockerfile Java version mismatch** - Updated from Java 21 to Java 17
- ✅ **Frontend-Backend Connection** - Auto-detects environment and connects appropriately
- ✅ **Dark Theme UI** - Professional dark mode with high contrast and better visibility
- ✅ **Button Visibility** - Enhanced button styles with clear hover states
- ✅ **Form Improvements** - Better input field visibility and focus states
- ✅ **Production Ready** - All configuration optimized for deployment

### 🎨 Design Enhancements
- Modern dark theme with professional color palette
- High-contrast text and buttons for better readability
- Smooth animations and transitions
- Responsive design for all screen sizes
- Enhanced modal and form styling

---

## 📁 Project Structure

```
ShopWave/
├── frontend/
│   ├── index.html          ← Main page
│   ├── css/
│   │   └── style.css       ← Dark theme styles
│   └── js/
│       └── app.js          ← Auto-connecting API logic
├── backend/
│   ├── pom.xml             ← Java 17 dependencies
│   ├── Dockerfile          ← Fixed to use Java 17
│   └── src/main/
│       ├── java/com/shopwave/
│       │   ├── controller/ ← REST endpoints
│       │   ├── service/    ← Business logic
│       │   ├── model/      ← JPA entities
│       │   ├── repository/ ← Database access
│       │   ├── security/   ← JWT authentication
│       │   └── config/     ← App configuration
│       └── resources/
│           └── application.properties
└── database/
    └── schema.sql          ← Database schema + sample data
```

---

## 🚀 Quick Start

### 1. Database Setup (MySQL)

```bash
# Create database
mysql -u root -p
CREATE DATABASE shopwave CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
exit;

# Import schema with sample data
mysql -u root -p shopwave < database/schema.sql
```

**Admin credentials (pre-seeded):**
- Email: `admin@shopwave.com`
- Password: `admin123`

---

### 2. Backend Setup

**Prerequisites:** 
- Java 17
- Maven 3.8+

```bash
cd backend

# Run with Maven
mvn spring-boot:run

# OR build JAR and run
mvn clean package -DskipTests
java -jar target/shopwave-backend-1.0.0.jar
```

**Backend will start at:** `http://localhost:8080/api`

**Swagger API Docs:** `http://localhost:8080/api/swagger-ui.html`

---

### 3. Frontend Setup

**Option A: VS Code Live Server** (Recommended)
1. Install "Live Server" extension in VS Code
2. Right-click `frontend/index.html` → **Open with Live Server**
3. Opens at `http://localhost:5500`

**Option B: Python HTTP Server**
```bash
cd frontend
python -m http.server 5500
```

**Option C: Direct Browser**
- Just open `frontend/index.html` in your browser

**The frontend automatically detects:**
- Local development → connects to `http://localhost:8080/api`
- Production → connects to deployed backend URL

---

## 🐳 Docker Deployment

### Build Docker Image

```bash
cd backend

# Build image
docker build -t shopwave-backend .

# Run container
docker run -p 8080:8080 \
  -e DB_URL=jdbc:postgresql://your-db-host:5432/shopwave \
  -e DB_USERNAME=your-username \
  -e DB_PASSWORD=your-password \
  -e JWT_SECRET=your-super-secret-key \
  shopwave-backend
```

---

## 🌐 Production Deployment

### Backend Options:

#### 1. Render (Recommended)
1. Create new Web Service
2. Connect your GitHub repository
3. Set build command: `cd backend && mvn clean install -DskipTests`
4. Set start command: `java -jar target/shopwave-backend-1.0.0.jar`
5. Add environment variables:
   ```
   PORT=8080
   DB_URL=jdbc:postgresql://your-db-url
   DB_USERNAME=your-username
   DB_PASSWORD=your-password
   DB_DRIVER=org.postgresql.Driver
   DB_DIALECT=org.hibernate.dialect.PostgreSQLDialect
   JWT_SECRET=your-256-bit-secret-key
   CORS_ALLOWED_ORIGINS=https://your-frontend.netlify.app
   ```

#### 2. Heroku
```bash
heroku create shopwave-backend
heroku addons:create heroku-postgresql:mini
git push heroku main
heroku config:set JWT_SECRET=your-secret-key
```

### Frontend Options:

#### 1. Netlify (Recommended)
```bash
cd frontend
netlify deploy --dir=. --prod
```

Or connect GitHub repository for auto-deployment.

#### 2. Vercel
```bash
cd frontend
vercel --prod
```

**After deployment:**
The app auto-detects production environment. If needed, update `frontend/js/app.js`:
```javascript
const API_BASE = window.location.hostname === 'localhost' 
  ? 'http://localhost:8080/api'
  : 'https://your-backend-url.com/api'; // Update this
```

---

## 🔐 Environment Variables

### Backend Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `8080` | Server port |
| `DB_URL` | `jdbc:mysql://localhost:3306/shopwave` | Database URL |
| `DB_USERNAME` | `root` | Database username |
| `DB_PASSWORD` | *(empty)* | Database password |
| `DB_DRIVER` | `com.mysql.cj.jdbc.Driver` | Database driver |
| `DB_DIALECT` | `org.hibernate.dialect.MySQL8Dialect` | Hibernate dialect |
| `JWT_SECRET` | *(default-change-in-prod)* | JWT signing key |
| `JWT_EXPIRATION_MS` | `86400000` | JWT expiry (24 hours) |
| `CORS_ALLOWED_ORIGINS` | `http://localhost:5500,...` | Allowed origins |

**⚠️ Important for Production:**
- Always set a strong `JWT_SECRET` (256-bit random string)
- Set `DB_PASSWORD` 
- Update `CORS_ALLOWED_ORIGINS` to your frontend URL
- Use PostgreSQL for production (MySQL for local dev)

---

## 🔑 API Endpoints

### Authentication
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/register` | ❌ | Register new user |
| POST | `/api/auth/login` | ❌ | Login and get JWT |

### Products
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/products` | ❌ | List all products |
| GET | `/api/products/{id}` | ❌ | Get by ID |
| GET | `/api/products/search?q=` | ❌ | Search products |
| POST | `/api/products` | ✅ Admin | Create product |

### Cart
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/cart` | ✅ | Get my cart |
| POST | `/api/cart/items` | ✅ | Add item |
| PUT | `/api/cart/items/{id}` | ✅ | Update quantity |
| DELETE | `/api/cart/items/{id}` | ✅ | Remove item |

### Orders
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/orders` | ✅ | Place order |
| GET | `/api/orders` | ✅ | My orders |
| PUT | `/api/orders/{id}/cancel` | ✅ | Cancel order |

---

## 🎨 Dark Theme Features

- **Professional color palette** with high contrast
- **Visible buttons** with hover effects and shadows
- **Clear form fields** with focus states
- **Smooth animations** and transitions
- **Accessible design** with proper color ratios
- **Responsive layout** for all devices

---

## 📝 Testing the Application

### 1. Test Backend
```bash
# Health check
curl http://localhost:8080/api/actuator/health

# Get products
curl http://localhost:8080/api/products

# Login
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@shopwave.com","password":"admin123"}'
```

### 2. Test Frontend
1. Open `http://localhost:5500` in browser
2. Click "Login" in top right
3. Use demo credentials (shown in modal)
4. Browse products, add to cart
5. Test search autocomplete
6. Place an order

---

## 🐛 Troubleshooting

### Backend won't start
- Check Java version: `java -version` (should be 17)
- Verify database is running
- Check database credentials in `application.properties`

### Frontend can't connect to backend
- Check backend is running on port 8080
- Verify CORS settings in backend
- Check browser console for errors

### Docker build fails
- Ensure Dockerfile uses Java 17 (not 21)
- Verify pom.xml is valid

---

## 📦 What's Included

### Sample Data
- ✅ Admin user (admin@shopwave.com / admin123)
- ✅ 6 product categories
- ✅ 6 sample products
- ✅ 3 coupons

### Features
- ✅ User authentication (JWT)
- ✅ Product catalog with search
- ✅ Shopping cart
- ✅ Order management
- ✅ Wishlist
- ✅ Admin panel ready
- ✅ Responsive design
- ✅ Dark theme

---

## 🚦 Production Checklist

### Before Deploying:
- [ ] Update `JWT_SECRET` to a strong random key
- [ ] Set production database credentials
- [ ] Update `CORS_ALLOWED_ORIGINS` to production URL
- [ ] Test all API endpoints
- [ ] Enable HTTPS/SSL
- [ ] Set up database backups
- [ ] Configure monitoring

---

**Built with ❤️ using Spring Boot & Vanilla JavaScript**

**Fixed & Enhanced - Ready for Production! 🚀**
